<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM contributions WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: view_contributions_all.php");
exit;
?>
