<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

// Fetch contributions
$sql = "SELECT c.id, u.username, c.amount, c.contribution_date, c.description 
        FROM contributions c 
        JOIN users u ON c.user_id = u.id 
        ORDER BY c.contribution_date DESC";
$result = $conn->query($sql);

$total = 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Contributions - Kiota Welfare</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 1100px; margin: auto; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 6px 12px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 12px; text-align: center; font-size: 14px; }
        th { background: #007BFF; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .total { margin-top: 20px; font-size: 18px; font-weight: bold; text-align: right; }
        .btn-container { text-align: right; margin-bottom: 15px; }
        .btn { display: inline-block; margin-left: 10px; padding: 8px 16px; background: #28a745; color: #fff; text-decoration: none; border-radius: 6px; transition: 0.3s; font-size: 13px; }
        .btn:hover { background: #218838; }
        .btn-edit { background: #ffc107; color: #000; }
        .btn-edit:hover { background: #e0a800; }
        .btn-delete { background: #dc3545; }
        .btn-delete:hover { background: #b02a37; }
    </style>
</head>
<body>
    <div class="container">
        <h2>All Contributions</h2>

        <!-- Export Buttons -->
        <div class="btn-container">
            <a href="export_contributions.php" class="btn">Export to Excel</a>
        </div>

        <!-- Contributions Table -->
        <table>
            <tr>
                <th>Member</th>
                <th>Amount (Ksh)</th>
                <th>Date</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= number_format($row['amount'],2) ?></td>
                    <td><?= $row['contribution_date'] ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td>
                        <a href="edit_contributions.php?id=<?= $row['id'] ?>" class="btn btn-edit"> Edit</a>
                        <a href="delete_contribution.php?id=<?= $row['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this contribution?');"> Delete</a>
                    </td>
                </tr>
                <?php $total += $row['amount']; ?>
            <?php endwhile; ?>
        </table>

        <div class="total">Total Collected: Ksh <?= number_format($total,2) ?></div>
        <p><a href="chairman.php">⬅ Back </a></p>
    </div>
</body>
</html>
