<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

$id = $_GET['id'];

// Fetch existing contribution
$sql = "SELECT * FROM contributions WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$contribution = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = $_POST['amount'];
    $date = $_POST['contribution_date'];
    $desc = $_POST['description'];

    $update = $conn->prepare("UPDATE contributions SET amount=?, contribution_date=?, description=? WHERE id=?");
    $update->bind_param("dssi", $amount, $date, $desc, $id);
    $update->execute();

    header("Location: view_contributions_all.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Contribution</title>
    <style>
        body { font-family: Arial; background: #f4f6f9; padding: 30px; }
        .form-box { max-width: 500px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 5px 10px rgba(0,0,0,0.1); }
        input, textarea { width: 100%; padding: 10px; margin: 10px 0; }
        button { background: #007BFF; color: white; padding: 10px 15px; border: none; border-radius: 5px; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>Edit Contribution</h2>
        <form method="post">
            <label>Amount:</label>
            <input type="number" step="0.01" name="amount" value="<?= $contribution['amount'] ?>" required>

            <label>Date:</label>
            <input type="date" name="contribution_date" value="<?= $contribution['contribution_date'] ?>" required>

            <label>Description:</label>
            <textarea name="description"><?= htmlspecialchars($contribution['description']) ?></textarea>

            <button type="submit">Update</button>
        </form>
         <p><a href="view_contributions_all.php">⬅ Back </a></p>
    </div>
</body>
</html>
