<?php
require_once "config.php"; // database connection

class AdminLogin {
    private string $error = '';

    public function authenticate(string $email, string $password, $conn): bool {
        // 🔹 Now using email for login
        $stmt = $conn->prepare("SELECT * FROM main WHERE email=? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // ✅ Case 1: password is hashed
            if (password_verify($password, $user['password'])) {
                $this->loginUser($user);
                return true;
            }

            // ✅ Case 2: legacy plain text password
            if ($password === $user['password']) {
                // Upgrade password to bcrypt
                $newHash = password_hash($password, PASSWORD_BCRYPT);
                $update = $conn->prepare("UPDATE main SET password=? WHERE id=?");
                $update->bind_param("si", $newHash, $user['id']);
                $update->execute();

                $this->loginUser($user);
                return true;
            }

            // ❌ Wrong password
            $this->error = "Incorrect password!";
        } else {
            $this->error = "No admin found with that email!";
        }

        return false;
    }

    private function loginUser(array $user): void {
        session_start();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = "admin"; // force admin role
        header("Location: signup.html"); // redirect after login
        exit;
    }

    public function getError(): string {
        return $this->error;
    }

    public function renderForm(): void {
        $errorHtml = $this->error ? "<p style='color:red'>{$this->error}</p>" : "";
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Admin Login - Kiota Welfare</title>
            <style>
                body {
                    font-family: Arial;
                    background: linear-gradient(135deg, #1b5e20, #43a047);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    margin: 0;
                }
                .container {
                    background: white;
                    padding: 30px;
                    border-radius: 12px;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                    width: 350px;
                    text-align: center;
                }
                input {
                    width: 100%;
                    padding: 10px;
                    margin: 8px 0;
                    border-radius: 6px;
                    border: 1px solid #ccc;
                }
                button {
                    width: 100%;
                    padding: 12px;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    font-weight: bold;
                    cursor: pointer;
                    margin-top: 10px;
                    background: #2E7D32;
                    transition: 0.3s;
                }
                button:hover {
                    background: #388E3C;
                    transform: scale(1.03);
                }
                h2 { margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Admin Login</h2>
                {$errorHtml}
                <form method="POST">
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit">Login</button>
                    <button type="button" class="extra-btn" onclick="location.href='password.php'">Forgot Password</button>
                </form>
            </div>
        </body>
        </html>
HTML;
    }
}

// Handle POST
$login = new AdminLogin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login->authenticate($_POST['email'], $_POST['password'], $conn);
}

// Render form
$login->renderForm();
?>
