<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

// Fetch contributions
$sql = "SELECT u.username, c.amount, c.contribution_date, c.description 
        FROM contributions c 
        JOIN users u ON c.user_id = u.id 
        ORDER BY c.contribution_date DESC";
$result = $conn->query($sql);

// Set headers for Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=contributions.xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "Member\tAmount\tDate\tDescription\n";

while ($row = $result->fetch_assoc()) {
    echo $row['username'] . "\t" . $row['amount'] . "\t" . $row['contribution_date'] . "\t" . $row['description'] . "\n";
}
exit;
?>
