<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'member') {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Contributions total
$contrib = $conn->query("SELECT SUM(amount) as total FROM contributions WHERE user_id=$user_id")->fetch_assoc()['total'] ?? 0;

// Support received
$support = $conn->query("SELECT SUM(amount) as total FROM support WHERE user_id=$user_id")->fetch_assoc()['total'] ?? 0;

// Net balance
$balance = $contrib - $support;
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Reports - Kiota Welfare</title>
    <style>
        body { font-family: Arial; background: url('images/member-bg.jpg') no-repeat center center fixed; background-size: cover; color: #fff; }
        .container { background: rgba(0,0,0,0.7); padding: 30px; width: 50%; margin: 100px auto; border-radius: 10px; text-align: center; }
        .stat { margin: 20px 0; font-size: 20px; }
        a { color: #ff9800; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>My Reports</h1>
    <div class="stat"> Total Contributions: <strong><?php echo number_format($contrib, 2); ?></strong></div>
    <div class="stat"> Total Welfare Support Received: <strong><?php echo number_format($support, 2); ?></strong></div>
    <div class="stat"> Net Balance: <strong><?php echo number_format($balance, 2); ?></strong></div>
    <p><a href="member.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
