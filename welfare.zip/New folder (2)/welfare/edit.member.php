<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'chairman') {
    header("Location: signin.php");
    exit;
}

require_once "config.php";

if (!isset($_GET['id'])) {
    header("Location: manage.members.php");
    exit;
}

$id = intval($_GET['id']);
$message = "";

// Fetch member
$stmt = $conn->prepare("SELECT id, username, email FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();
$stmt->close();

if (!$member) {
    die("Member not found.");
}

// Update member
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);

    $stmt = $conn->prepare("UPDATE users SET username=?, email=? WHERE id=?");
    $stmt->bind_param("ssi", $username, $email, $id);

    if ($stmt->execute()) {
        $message = " Member updated successfully!";
        // Refresh updated details
        $member['username'] = $username;
        $member['email'] = $email;
    } else {
        $message = " Error updating member.";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Member - Kiota Welfare</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            color: #f4f4f9;
            margin: 0;
            padding: 30px;
        }

        .container {
            background: rgba(255,255,255,0.1);
            padding: 25px;
            border-radius: 12px;
            backdrop-filter: blur(8px);
            max-width: 600px;
            margin: auto;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        h1 {
            text-align: center;
            color: #ffca28;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 15px;
            font-weight: bold;
        }

        input {
            padding: 10px;
            border-radius: 8px;
            border: none;
            margin-top: 5px;
            font-size: 16px;
            width: 100%;
        }

        button {
            margin-top: 20px;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background: #42a5f5;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: #1565c0;
        }

        .back {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            border-radius: 20px;
            background: #26a69a;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .back:hover {
            background: #00796b;
        }

        .message {
            margin-top: 15px;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Member</h1>

        <?php if ($message): ?>
            <p class="message"><?= $message; ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>Username:</label>
            <input type="text" name="username" value="<?= htmlspecialchars($member['username']); ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($member['email']); ?>" required>

            <button type="submit"> Save Changes</button>
        </form>

        <a href="manage.members.php" class="back">⬅ Back to Members</a>
    </div>
</body>
</html>
