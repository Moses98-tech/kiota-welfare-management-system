<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'treasurer') {
    header("Location: signin.php");
    exit;
}

// Total Contributions
$totalContributions = $conn->query("SELECT SUM(amount) as total FROM contributions")->fetch_assoc()['total'];

// Total Support
$totalSupport = $conn->query("SELECT SUM(amount) as total FROM welfare_support")->fetch_assoc()['total'];

// Member Contributions (detailed)
$memberContribs = $conn->query("
    SELECT u.username, SUM(c.amount) as total
    FROM contributions c
    JOIN users u ON c.user_id = u.id
    GROUP BY u.username
");

// Member Supports (detailed)
$memberSupports = $conn->query("
    SELECT u.username, ws.support_type, SUM(ws.amount) as total
    FROM welfare_support ws
    JOIN users u ON ws.user_id = u.id
    GROUP BY u.username, ws.support_type
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Treasurer Reports - Kiota Welfare</title>
    <style>
        body { font-family: Arial; background:url('images/reports-bg.jpg') no-repeat center center fixed; background-size:cover; color:#fff; }
        .container { background:rgba(0,0,0,0.85); padding:30px; width:80%; margin:30px auto; border-radius:10px; }
        h1, h2 { color:#ff9800; }
        table { width:100%; border-collapse:collapse; margin:20px 0; background:#fff; color:#000; }
        th, td { padding:10px; border:1px solid #ddd; text-align:center; }
        th { background:#2196F3; color:#fff; }
        tr:nth-child(even){ background:#f2f2f2; }
        a { color:#ff9800; text-decoration:none; }
        a:hover { text-decoration:underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>Treasurer Reports</h1>

    <h2>Overall Summary</h2>
    <p><strong>Total Contributions:</strong> Ksh <?php echo number_format($totalContributions, 2); ?></p>
    <p><strong>Total Support Given:</strong> Ksh <?php echo number_format($totalSupport, 2); ?></p>
    <p><strong>Balance:</strong> Ksh <?php echo number_format($totalContributions - $totalSupport, 2); ?></p>

    <h2>Member Contributions</h2>
    <table>
        <tr>
            <th>Member</th>
            <th>Total Contributions (Ksh)</th>
        </tr>
        <?php while($row = $memberContribs->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo number_format($row['total'], 2); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <h2>Member Support</h2>
    <table>
        <tr>
            <th>Member</th>
            <th>Support Type</th>
            <th>Total Support (Ksh)</th>
        </tr>
        <?php while($row = $memberSupports->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo ucfirst($row['support_type']); ?></td>
            <td><?php echo number_format($row['total'], 2); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <p><a href="treasurer.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
