<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'member') {
    header("Location: signin.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user_id = $_SESSION['user_id'];
    $amount = floatval($_POST['amount']);
    $desc   = $conn->real_escape_string($_POST['description']);
    $date   = date("Y-m-d");

    if ($amount > 0) {
        $sql = "INSERT INTO contributions (user_id, amount, contribution_date, description) 
                VALUES ('$user_id', '$amount', '$date', '$desc')";
        if ($conn->query($sql)) {
            $success = "Contribution of Ksh. " . number_format($amount, 2) . " recorded successfully!";
        } else {
            $error = "Error: " . $conn->error;
        }
    } else {
        $error = "Please enter a valid amount.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Make Contribution - Kiota Welfare</title>
    <style>
        body { font-family: Arial; background: url('images/member-bg.jpg') no-repeat center center fixed; background-size: cover; color: #fff; }
        .container { background: rgba(0,0,0,0.8); padding: 30px; width: 40%; margin: 100px auto; border-radius: 10px; }
        input, textarea { width: 100%; padding: 10px; margin: 10px 0; border-radius: 5px; border: none; }
        button { background: #ff9800; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; color: #fff; font-weight: bold; }
        button:hover { background: #e68a00; }
        .msg { margin: 10px 0; padding: 10px; border-radius: 5px; }
        .success { background: #4CAF50; }
        .error { background: #f44336; }
        a { color: #ff9800; text-decoration: none; }
    </style>
</head>
<body>
<div class="container">
    <h1>Make Contribution</h1>
    <?php if (isset($success)) echo "<div class='msg success'>$success</div>"; ?>
    <?php if (isset($error)) echo "<div class='msg error'>$error</div>"; ?>
    <form method="post">
        <label>Contribution Amount (Ksh):</label>
        <input type="number" step="0.01" name="amount" required>

        <label>Description (e.g., Monthly Contribution, Event, etc.):</label>
        <textarea name="description"></textarea>

        <button type="submit">Submit Contribution</button>
    </form>
    <p><a href="member.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
