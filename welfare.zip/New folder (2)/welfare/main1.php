<?php
require_once "config.php"; // DB connection

class Login {
    protected string $role;
    protected string $redirectPage;
    protected string $error = '';

    public function __construct(string $role, string $redirectPage) {
        $this->role = $role;
        $this->redirectPage = $redirectPage;
        if(session_status() == PHP_SESSION_NONE){
            session_start();
        }
    }

    public function authenticate(string $username, string $password, $conn): bool {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND role=? LIMIT 1");
        $stmt->bind_param("ss", $username, $this->role);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                header("Location: {$this->redirectPage}");
                exit;
            } else {
                $this->error = "Incorrect password!";
            }
        } else {
            $this->error = "No {$this->role} found with that username!";
        }
        return false;
    }

    public function renderForm(): void {
        $errorHtml = $this->error ? "<p style='color:red'>{$this->error}</p>" : "";
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Kiota Welfare Management System</title>
            <style>
                body { 
                    font-family: Arial, sans-serif; 
                    background: linear-gradient(135deg, #1b5e20, #43a047); 
                    display:flex; 
                    justify-content:center; 
                    align-items:center; 
                    min-height:100vh; 
                    margin:0;
                }
                .container { 
                    background:white; 
                    padding:30px; 
                    border-radius:12px; 
                    box-shadow:0 4px 10px rgba(0,0,0,0.2); 
                    width:350px; 
                    text-align:center; 
                }
                input, select { 
                    width:100%; 
                    padding:10px; 
                    margin:8px 0; 
                    border-radius:6px; 
                    border:1px solid #ccc; 
                }
                button { 
                    width:100%; 
                    padding:12px; 
                    color:white; 
                    border:none; 
                    border-radius:6px; 
                    font-weight:bold; 
                    cursor:pointer; 
                    margin-top:10px; 
                    transition:0.3s;
                }
                button:hover { transform: scale(1.03); }
                .login-btn { background:#2E7D32; }
                .login-btn:hover { background:#388E3C; }
                .extra-btn { background:#1b5e20; margin-bottom:15px; }
                .extra-btn:hover { background:#43a047; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Kiota Welfare Management System</h2>
                {$errorHtml}
                
                
                

                <form method="POST">
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <select name="role" required>
                        <option value="">Select Role</option>
                        <option value="member">Member</option>
                        <option value="treasurer">Treasurer</option>
                        <option value="chairman">Chairman</option>
                        
                    </select>
                    <button type="button" class="extra-btn" onclick="location.href='admin_login.php'">Admin Panel for Registration</button>
                    <button type="submit" class="login-btn">Login</button>
                    <button type="button" class="extra-btn" onclick="location.href='reset.php'">Forgot Passwrod</button>
                </form>
            </div>
        </body>
        </html>
HTML;
    }
}

// Handle form submission
$login = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];
    $redirect = match($role) {
        'member' => 'member.php',
        'treasurer' => 'treasurer.php',
        'chairman' => 'chairman.php',
        
        default => '#',
    };
    $login = new Login($role, $redirect);
    $login->authenticate($_POST['username'], $_POST['password'], $conn);
} else {
    $login = new Login('', '#'); // initial render
}

// Render login form
$login->renderForm();
?>
