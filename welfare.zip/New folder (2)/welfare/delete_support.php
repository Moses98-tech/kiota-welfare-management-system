<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

if (!isset($_GET['id'])) {
    die(" Support ID is missing.");
}

$id = intval($_GET['id']);

$sql = "DELETE FROM welfare_support WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: view_support_all.php?msg=deleted");
    exit;
} else {
    echo "Error deleting record.";
}
?>
