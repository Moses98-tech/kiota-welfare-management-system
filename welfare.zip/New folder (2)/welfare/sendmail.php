<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// DB connection
$mysqli = new mysqli("localhost", "root", "", "kws"); 
if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: " . $mysqli->connect_error);
}

// Load PHPMailer
require_once __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// SMTP settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'josephkimani0101@gmail.com');
define('SMTP_PASSWORD', 'pfla pvdu ifem gzsz'); // Gmail App Password
define('SMTP_PORT', 587);
define('SMTP_ENCRYPTION', 'tls');
define('DEFAULT_FROM_EMAIL', 'josephkimani0101@gmail.com');
define('DEFAULT_FROM_NAME', 'Kiota Welfare');
define('DEFAULT_SUBJECT', 'Kiota Welfare Notification');

// CSRF
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Email Template function ✅
function getEmailTemplate($content, $title = "Kiota Welfare") {
    return '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($title) . '</title>
    </head>
    <body style="font-family: Arial, sans-serif; background:#f9fafb; margin:0; padding:0;">
        <div style="max-width:600px; margin:20px auto; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 4px 10px rgba(0,0,0,0.05);">
            
            <!-- Header -->
            <div style="background:linear-gradient(to right,#4F46E5,#7C3AED); padding:20px; text-align:center;">
                <h1 style="margin:0; color:#fff;">Kiota Welfare</h1>
            </div>

            <!-- Message Body -->
            <div style="padding:25px; color:#333; line-height:1.6;">
                ' . $content . '
            </div>

            <!-- Footer -->
            <div style="background:#f3f4f6; padding:15px; text-align:center; font-size:13px; color:#6b7280;">
                <p>&copy; ' . date("Y") . ' Kiota Welfare. All rights reserved.</p>
                <p>For inquiries, contact us at <a href="mailto:support@kiotawelfare.org">support@kiotawelfare.org</a></p>
            </div>
        </div>
    </body>
    </html>';
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Security token validation failed.";
    } else {
        $recipients = $_POST['emails'] ?? [];
        $subject = !empty($_POST['subject']) ? htmlspecialchars($_POST['subject']) : DEFAULT_SUBJECT;
        $message = !empty($_POST['message']) ? nl2br(htmlspecialchars($_POST['message'])) : 'Hello from Kiota Welfare';

        if (!empty($recipients)) {
            $successCount = 0;
            $failCount = 0;

            foreach ($recipients as $recipient) {
                if (filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
                    $mail = new PHPMailer(true);
                    try {
                        $mail->isSMTP();
                        $mail->Host = SMTP_HOST;
                        $mail->SMTPAuth = true;
                        $mail->Username = SMTP_USERNAME;
                        $mail->Password = SMTP_PASSWORD;
                        $mail->SMTPSecure = SMTP_ENCRYPTION;
                        $mail->Port = SMTP_PORT;

                        $mail->setFrom(DEFAULT_FROM_EMAIL, DEFAULT_FROM_NAME);
                        $mail->addAddress($recipient);

                        $mail->isHTML(true);
                        $mail->Subject = $subject;
                        // ✅ Wrap message inside branded template
                        $mail->Body = getEmailTemplate($message, $subject);
                        $mail->AltBody = strip_tags($message);

                        $mail->send();
                        $successCount++;
                    } catch (Exception $e) {
                        $failCount++;
                    }
                }
            }

            $success = "✅ Emails sent successfully to {$successCount} members.";
            if ($failCount > 0) {
                $error = "❌ Failed to send to {$failCount} members.";
            }
        } else {
            $error = "Please select at least one recipient.";
        }
    }
}

// Fetch active users
$users = [];
$result = $mysqli->query("SELECT id, fullname, email FROM users WHERE status='Active'");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Bulk Email - Kiota Welfare</title>
    <style>
        body {font-family: Arial, sans-serif; background: #f9fafb; padding: 30px;}
        .container {background: #fff; padding: 20px; border-radius: 10px; max-width: 600px; margin: auto; box-shadow: 0 5px 15px rgba(0,0,0,0.1);}
        h2 {text-align: center;}
        .alert {padding: 10px; margin-bottom: 15px; border-radius: 6px;}
        .alert-success {background: #d1fae5; color: #065f46;}
        .alert-error {background: #fee2e2; color: #991b1b;}
        label {display: block; margin-top: 10px; font-weight: bold;}
        select, input, textarea, button {width: 100%; padding: 10px; margin-top: 5px; border-radius: 6px; border: 1px solid #ccc;}
        select[multiple] {height: 150px;}
        button {background: #4F46E5; color: white; border: none; cursor: pointer;}
        button:hover {background: #4338ca;}
    </style>
</head>
<body>
<div class="container">
    <h2>Send Bulk Email</h2>

    <?php if (isset($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
    <?php if (isset($error)): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

        <label for="emails">Select Members (hold CTRL to select multiple)</label>
        <select name="emails[]" id="emails" multiple required>
            <?php foreach ($users as $user): ?>
                <option value="<?php echo htmlspecialchars($user['email']); ?>">
                    <?php echo htmlspecialchars($user['fullname']) . " (" . $user['email'] . ")"; ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="subject">Subject</label>
        <input type="text" id="subject" name="subject" required>

        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5" required></textarea>

        <button type="submit">Send Emails</button>
    </form>
</div>
<p><a href="chairman.php">⬅ Back to Dashboard</a></p>
</body>
</html>
