<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit;
}
echo "<h1>Welcome, you are logged in as " . $_SESSION['role'] . "</h1>";
echo "<a href='logout.php'>Logout</a>";
?>
