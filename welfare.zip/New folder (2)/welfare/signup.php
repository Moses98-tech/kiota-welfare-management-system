<?php
include "config.php";
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email    = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role     = $conn->real_escape_string($_POST['role']); 
    $mpesa    = $conn->real_escape_string($_POST['mpesa_code']); 
    $check = $conn->query("SELECT * FROM users WHERE username='$username' OR email='$email'");
    if ($check->num_rows > 0) {
        echo "exists";
    } else {
        $sql = "INSERT INTO users (username, password, role, fullname, email, status) 
                VALUES ('$username', '$password', '$role', '$fullname', '$email', 'Inactive')";
        if ($conn->query($sql)) {
            // also record Mpesa registration payment
            $user_id = $conn->insert_id;
            $conn->query("INSERT INTO registration_fees (user_id, mpesa_code, verified) 
                          VALUES ('$user_id', '$mpesa', 0)");
            
            echo "success";
        } else {
            echo "error";
        }
    }
}
?>
