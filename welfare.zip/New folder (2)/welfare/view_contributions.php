<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'member') {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$res = $conn->query("SELECT * FROM contributions WHERE user_id=$user_id ORDER BY contribution_date DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Contributions - Kiota Welfare</title>
    <style>
        body { font-family: Arial; background: url('images/member-bg.jpg') no-repeat center center fixed; background-size: cover; color: #fff; }
        .container { background: rgba(0,0,0,0.7); padding: 20px; width: 70%; margin: 50px auto; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #fff; padding: 10px; text-align: left; }
        a { color: #ff9800; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>My Contributions</h1>
    <table>
        <tr>
            <th>Date</th>
            <th>Amount</th>
            <th>Description</th>
        </tr>
        <?php while($row = $res->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['contribution_date']; ?></td>
            <td><?php echo number_format($row['amount'], 2); ?></td>
            <td><?php echo $row['description']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <p><a href="member.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
