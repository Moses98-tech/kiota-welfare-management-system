<?php
// Configuration Section - Update these values for your database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = "";     // Your database password
$dbname = "kws"; // Your database name

// Recommended: Create a separate table to store password reset tokens.
// Here is the SQL to create this table. Copy and paste it into your database management tool (e.g., phpMyAdmin) and run it.
/*
CREATE TABLE `password_resets` (
  `email` varchar(150) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add primary key and index for faster lookup
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `token` (`token`);
*/

// Set a timezone for consistent timestamping
date_default_timezone_set('Asia/Kolkata'); // Or your local timezone

// Function to generate a secure random token
function generateToken() {
    return bin2hex(random_bytes(32));
}

// Start a session to store messages
session_start();

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the request is for a password reset
    if (isset($_POST['email'])) {
        // --- Step 1: Handle "Forgot Password" request ---
        $email = $conn->real_escape_string($_POST['email']);

        // Check if the email exists in the users table
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Email exists, generate a unique token
            $token = generateToken();
            $hashedToken = password_hash($token, PASSWORD_DEFAULT);

            // Insert or update the password_resets table
            // This prevents multiple tokens for the same user
            $insert_stmt = $conn->prepare("INSERT INTO password_resets (email, token) VALUES (?, ?) ON DUPLICATE KEY UPDATE token = ?");
            $insert_stmt->bind_param("sss", $email, $hashedToken, $hashedToken);
            $insert_stmt->execute();
            $insert_stmt->close();

            // --- IMPORTANT: This part simulates the email sending process ---
            // In a real application, you would use a mail library (like PHPMailer)
            // and an SMTP server to send this email.
            // For this example, we'll just display the link.
            $resetLink = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . "?token=" . $token;
            
            $_SESSION['message'] = "A password reset link has been sent to your email address. For this example, here is the link: <br><a href='$resetLink'>$resetLink</a>";
            $_SESSION['type'] = 'success';
        } else {
            // Email does not exist, but for security, we give a generic response
            $_SESSION['message'] = "If a matching email address was found, a password reset link has been sent.";
            $_SESSION['type'] = 'info';
        }
        
        $stmt->close();
        $conn->close();

        // Redirect to avoid form resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } elseif (isset($_POST['password']) && isset($_POST['token'])) {
        // --- Step 2: Handle "Reset Password" submission ---
        $token = $conn->real_escape_string($_POST['token']);
        $newPassword = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];

        if ($newPassword !== $confirmPassword) {
            $_SESSION['message'] = "Passwords do not match.";
            $_SESSION['type'] = 'error';
        } elseif (strlen($newPassword) < 8) {
            $_SESSION['message'] = "Password must be at least 8 characters long.";
            $_SESSION['type'] = 'error';
        } else {
            // Check for the token in the database and its expiration (1 hour)
            $stmt = $conn->prepare("SELECT email, token FROM password_resets WHERE created_at > (NOW() - INTERVAL 1 HOUR)");
            $stmt->execute();
            $result = $stmt->get_result();
            $found_token = false;

            while($row = $result->fetch_assoc()) {
                if (password_verify($token, $row['token'])) {
                    $email = $row['email'];
                    $found_token = true;
                    break;
                }
            }
            $stmt->close();

            if ($found_token) {
                // Token is valid and not expired, hash the new password and update the user
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
                $update_stmt->bind_param("ss", $hashedPassword, $email);
                $update_stmt->execute();
                $update_stmt->close();

                // Delete the used token from the password_resets table
                $delete_stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
                $delete_stmt->bind_param("s", $email);
                $delete_stmt->execute();
                $delete_stmt->close();

                $_SESSION['message'] = "Your password has been reset successfully. You can now log in with your new password.";
                $_SESSION['type'] = 'success';
            } else {
                $_SESSION['message'] = "Invalid or expired password reset token. Please try again.";
                $_SESSION['type'] = 'error';
            }
        }
        $conn->close();

        // Redirect to avoid form resubmission
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Clear any old messages after displaying them
$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$type = isset($_SESSION['type']) ? $_SESSION['type'] : '';
unset($_SESSION['message']);
unset($_SESSION['type']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
            text-align: center;
        }
        h1 {
            font-size: 1.75rem;
            font-weight: 600;
            color: #1a202c;
            margin-bottom: 1.5rem;
        }
        .message-box {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            font-weight: 500;
            line-height: 1.5;
            text-align: left;
        }
        .message-box.success {
            background-color: #d1fae5;
            color: #065f46;
        }
        .message-box.error {
            background-color: #fee2e2;
            color: #991b1b;
        }
        .message-box.info {
            background-color: #dbeafe;
            color: #1e40af;
        }
        .form-group {
            margin-bottom: 1.25rem;
            text-align: left;
        }
        .form-group label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        .form-group input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        .form-group input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }
        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #3b82f6;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .btn:hover {
            background-color: #2563eb;
        }
        .back-link {
            display: block;
            margin-top: 1.5rem;
            font-size: 0.875rem;
            color: #64748b;
            text-decoration: none;
            transition: color 0.2s ease;
        }
        .back-link:hover {
            color: #1a202c;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($message)): ?>
            <div class="message-box <?php echo $type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if (!isset($_GET['token'])): ?>
            <!-- Form to request password reset -->
            <h1>Forgot Password</h1>
            <p style="margin-bottom: 1.5rem; color: #64748b; line-height: 1.5;">Enter your email and we'll send you a link to reset your password.</p>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <button type="submit" class="btn">Send Reset Link</button>
            </form>
            <a href="main1.php" class="back-link">Back to login</a>
        <?php else: ?>
            <?php
            // Connect to the database
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // --- Step 3: Handle the reset password form after clicking the email link ---
            $token = $conn->real_escape_string($_GET['token']);
            $validToken = false;
            $email = '';

            // Check if the token is valid and not expired (1 hour)
            $stmt = $conn->prepare("SELECT email, token FROM password_resets WHERE created_at > (NOW() - INTERVAL 1 HOUR)");
            $stmt->execute();
            $result = $stmt->get_result();

            while($row = $result->fetch_assoc()) {
                if (password_verify($token, $row['token'])) {
                    $email = $row['email'];
                    $validToken = true;
                    break;
                }
            }
            $stmt->close();
            $conn->close();

            if ($validToken): ?>
                <h1>Set New Password</h1>
                <p style="margin-bottom: 1.5rem; color: #64748b; line-height: 1.5;">Please enter and confirm your new password.</p>
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn">Reset Password</button>
                </form>
            <?php else: ?>
                <h1>Invalid Link</h1>
                <p style="margin-bottom: 1.5rem; color: #ef4444; line-height: 1.5;">This password reset link is invalid or has expired. Please request a new one.</p>
                <a href="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="btn">Request New Link</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
