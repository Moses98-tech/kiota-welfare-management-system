<?php
session_start();
if (!isset($_SESSION['role'])) { 
    header("Location: index.html"); 
    exit; 
}

include 'config.php';

// Fetch all payment proofs
$sql = "SELECT * FROM payment_proofs ORDER BY uploaded_at DESC";
$result = $conn->query($sql);

// Summary values
$total_records = 0;
$total_approved = 0;
$total_pending = 0;
$total_rejected = 0;

$payments = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $payments[] = $row;
        $total_records++;

        if ($row['status'] == 'Approved') {
            $total_approved += $row['amount'];
        } elseif ($row['status'] == 'Pending') {
            $total_pending += $row['amount'];
        } elseif ($row['status'] == 'Rejected') {
            $total_rejected += $row['amount'];
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Fees Report</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 1000px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background: #007bff; color: #fff; }
        tr:nth-child(even) { background: #f9f9f9; }
        .summary { margin-top: 20px; padding: 15px; background: #f1f1f1; border-radius: 6px; }
        .Approved { color: green; font-weight: bold; }
        .Pending { color: orange; font-weight: bold; }
        .Rejected { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2>📊 Registration Fees Report</h2>
        
        <div class="summary">
            <p><strong>Total Records:</strong> <?= $total_records ?></p>
            <p><strong>Total Approved (Collected):</strong> Ksh <?= number_format($total_approved,2) ?></p>
            <p><strong>Total Pending:</strong> Ksh <?= number_format($total_pending,2) ?></p>
            <p><strong>Total Rejected:</strong> Ksh <?= number_format($total_rejected,2) ?></p>
        </div>

        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Amount (Ksh)</th>
                <th>Status</th>
                <th>Uploaded At</th>
                <th>Proof</th>
            </tr>
            <?php foreach ($payments as $pay): ?>
                <tr>
                    <td><?= $pay['id'] ?></td>
                    <td><?= htmlspecialchars($pay['username']) ?></td>
                    <td><?= number_format($pay['amount'],2) ?></td>
                    <td class="<?= $pay['status'] ?>"><?= $pay['status'] ?></td>
                    <td><?= $pay['uploaded_at'] ?></td>
                    <td>
                        <?php if (!empty($pay['proof_file'])): ?>
                            <a href="uploads/<?= $pay['proof_file'] ?>" target="_blank">View Proof</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
     <p><a href="chairman.php">⬅ Back </a></p>
</body>
</html>
