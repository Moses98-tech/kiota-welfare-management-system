<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

// Fetch support records
$sql = "SELECT * FROM welfare_support ORDER BY support_date DESC";
$result = $conn->query($sql);

$total = 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Support - Kiota Welfare</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: auto; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 6px 12px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 12px; text-align: center; font-size: 14px; }
        th { background: #007BFF; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .total { margin-top: 20px; font-size: 18px; font-weight: bold; text-align: right; }
        .btn { padding: 6px 12px; border-radius: 6px; text-decoration: none; color: #fff; font-size: 13px; }
        .btn-edit { background: #28a745; }
        .btn-edit:hover { background: #218838; }
        .btn-del { background: #dc3545; }
        .btn-del:hover { background: #b02a37; }
    </style>
</head>
<body>
    <div class="container">
        <h2> All Support Records</h2>

        <!-- Support Table -->
        <table>
            <tr>
                <th>Support Type</th>
                <th>Amount (Ksh)</th>
                <th>Date</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['support_type']) ?></td>
                    <td><?= number_format($row['amount'],2) ?></td>
                    <td><?= $row['support_date'] ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td>
                        <a href="edit_support.php?id=<?= $row['id'] ?>" class="btn btn-edit">Edit</a>
                        <a href="delete_support.php?id=<?= $row['id'] ?>" class="btn btn-del" onclick="return confirm('Are you sure you want to delete this record?')">🗑 Delete</a>
                    </td>
                </tr>
                <?php $total += $row['amount']; ?>
            <?php endwhile; ?>
        </table>

        <div class="total">Total Support: Ksh <?= number_format($total,2) ?></div>
         <p><a href="chairman.php">⬅ Back </a></p>
    </div>
</body>
</html>
