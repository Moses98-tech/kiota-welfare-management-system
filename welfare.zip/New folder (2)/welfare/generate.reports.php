<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

// Fetch contributions per member
$contrib_sql = "
    SELECT u.username, SUM(c.amount) AS total_contrib 
    FROM users u 
    LEFT JOIN contributions c ON u.id = c.user_id 
    GROUP BY u.id
";
$contrib_result = $conn->query($contrib_sql);

// Fetch support per member
$support_sql = "
    SELECT u.username, SUM(s.amount) AS total_support 
    FROM users u 
    LEFT JOIN support s ON u.id = s.user_id 
    GROUP BY u.id
";
$support_result = $conn->query($support_sql);

// Merge results by username
$report = [];
while($row = $contrib_result->fetch_assoc()){
    $report[$row['username']]['contrib'] = $row['total_contrib'] ?? 0;
}
while($row = $support_result->fetch_assoc()){
    $report[$row['username']]['support'] = $row['total_support'] ?? 0;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Overall Reports - Kiota Welfare</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: auto; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 6px 12px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 12px; text-align: center; font-size: 14px; }
        th { background: #17a2b8; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .total { margin-top: 20px; font-size: 18px; font-weight: bold; text-align: right; }
        .btn { display: inline-block; margin: 5px; padding: 10px 20px; border-radius: 6px; text-decoration: none; color: #fff; }
        .btn-excel { background: #28a745; }
        .btn-excel:hover { background: #218838; }
        .btn-pdf { background: #dc3545; }
        .btn-pdf:hover { background: #b02a37; }
    </style>
</head>
<body>
    <div class="container">
        <h2> Overall Reports</h2>

        <div class="btn-container">
            <a href="export_overall_excel.php" class="btn btn-excel"> Export Report to Excel</a>
            
        </div>

        <table>
            <tr>
                <th>Member</th>
                <th>Total Contributions (Ksh)</th>
                <th>Total Support (Ksh)</th>
                <th>Net Balance (Ksh)</th>
            </tr>
            <?php 
            $grand_total_contrib = 0;
            $grand_total_support = 0;
            foreach($report as $username => $data):
                $total_contrib = $data['contrib'] ?? 0;
                $total_support = $data['support'] ?? 0;
                $net = $total_contrib - $total_support;
                $grand_total_contrib += $total_contrib;
                $grand_total_support += $total_support;
            ?>
            <tr>
                <td><?= htmlspecialchars($username) ?></td>
                <td><?= number_format($total_contrib,2) ?></td>
                <td><?= number_format($total_support,2) ?></td>
                <td><?= number_format($net,2) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>

        <div class="total">
            Grand Total Contributions: Ksh <?= number_format($grand_total_contrib,2) ?> | 
            Grand Total Support: Ksh <?= number_format($grand_total_support,2) ?> | 
            Overall Net Balance: Ksh <?= number_format($grand_total_contrib - $grand_total_support,2) ?>
        </div>
        <p><a href="chairman.php">⬅ Back </a></p>
    </div>
</body>
</html>
