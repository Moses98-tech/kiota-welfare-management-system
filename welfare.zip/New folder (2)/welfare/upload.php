<?php
require_once "config.php"; // Database connection
session_start();

// Assuming user is logged in
$user_id = $_SESSION['id'] ?? 0;
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = $_POST['amount'];
    $mpesa_code = $_POST['mpesa_code']; // ✅ Capture M-Pesa code

    if (!empty($_FILES["payment_proof"]["name"])) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $fileName = time() . "_" . basename($_FILES["payment_proof"]["name"]);
        $targetFile = $targetDir . $fileName;

        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowed = ["jpg","jpeg","png","pdf"];

        if (in_array($fileType, $allowed)) {
            if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $targetFile)) {
                
                // ✅ Save with mpesa_code
                $stmt = $conn->prepare("INSERT INTO payment_proofs (id, amount, mpesa_code, proof_file) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("idss", $user_id, $amount, $mpesa_code, $fileName);

                if ($stmt->execute()) {
                    $message = "✅ Proof uploaded successfully!";
                } else {
                    $message = "❌ Database error: " . $conn->error;
                }
            } else {
                $message = "❌ Failed to upload file.";
            }
        } else {
            $message = "❌ Invalid file type. Only JPG, PNG, PDF allowed.";
        }
    } else {
        $message = "❌ Please select a file.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Upload Payment Proof</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
    .container { width: 420px; margin: auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); }
    input, button { width: 100%; padding: 10px; margin: 8px 0; border-radius: 6px; border: 1px solid #ccc; }
    button { background: #0D47A1; color: white; border: none; cursor: pointer; }
    button:hover { background: #1565C0; }
    .msg { margin-top: 15px; font-weight: bold; color: green; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Upload Payment Proof</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Amount Paid (KES):</label>
        <input type="number" step="0.01" name="amount" placeholder="Enter Amount Paid" required>

        <label>M-Pesa Authorization Code:</label>
        <input type="text" name="mpesa_code" maxlength="20" placeholder="e.g. QBC123XYZ9" required>

        <label>Upload Payment Proof (screenshot/PDF):</label>
        <input type="file" name="payment_proof" accept="image/*,.pdf" required>

        <button type="submit">Upload Proof</button>
    </form>

    <div class="msg"><?= $message; ?></div>
  </div>
  <p><a href="signup.html">⬅ Back </a></p>
</body>
</html>
