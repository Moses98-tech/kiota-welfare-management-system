<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'treasurer') {
    header("Location: signin.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $member_id = $_POST['member_id'];
    $amount = $_POST['amount'];
    $description = $_POST['description'];
    $date = date("Y-m-d");

    $stmt = $conn->prepare("INSERT INTO contributions (user_id, amount, contribution_date, description) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("idss", $member_id, $amount, $date, $description);

    if ($stmt->execute()) {
        $success = "Contribution recorded successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
$members = $conn->query("SELECT id, username FROM users WHERE role='member'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Record Contribution</title>
    <style>
        body { font-family:Arial; background:url('images/treasurer-bg.jpg') no-repeat center center fixed; background-size:cover; color:#fff; }
        .form-container { background:rgba(0,0,0,0.85); padding:30px; width:50%; margin:50px auto; border-radius:10px; }
        input, select, textarea { width:100%; padding:10px; margin:10px 0; border-radius:5px; border:none; }
        button { padding:10px 20px; background:#2196F3; color:#fff; border:none; border-radius:5px; cursor:pointer; }
        button:hover { background:#1976D2; }
        .msg { margin:15px 0; padding:10px; border-radius:5px; }
        .success { background:#4CAF50; color:#fff; }
        .error { background:#f44336; color:#fff; }
    </style>
</head>
<body>
<div class="form-container">
    <h1>Record Member Contribution</h1>
    <?php if(isset($success)) echo "<p class='msg success'>$success</p>"; ?>
    <?php if(isset($error)) echo "<p class='msg error'>$error</p>"; ?>
    
    <form method="POST">
        <label for="member_id">Select Member</label>
        <select name="member_id" required>
            <option value="">-- Select Member --</option>
            <?php while($row = $members->fetch_assoc()): ?>
                <option value="<?php echo $row['id']; ?>"><?php echo $row['username']; ?></option>
            <?php endwhile; ?>
        </select>

        <label for="amount">Contribution Amount (Ksh)</label>
        <input type="number" step="0.01" name="amount" required>

        <label for="description">Description</label>
        <textarea name="description" rows="3"></textarea>

        <button type="submit">Save Contribution</button>
    </form>
    <p><a href="treasurer.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
