<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'member') {
    header("Location: signin.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM welfare_support WHERE user_id='$user_id' ORDER BY support_date DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Welfare Support - Kiota Welfare</title>
    <style>
        body { font-family: Arial; background: url('images/member-bg.jpg') no-repeat center center fixed; background-size: cover; color: #fff; }
        .container { background: rgba(0,0,0,0.8); padding: 30px; width: 60%; margin: 50px auto; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border-bottom: 1px solid #ccc; }
        th { background: #ff9800; color: #fff; }
        tr:hover { background: rgba(255, 255, 255, 0.1); }
        a { color: #ff9800; text-decoration: none; }
    </style>
</head>
<body>
<div class="container">
    <h1>My Welfare Support</h1>
    <table>
        <tr>
            <th>Date</th>
            <th>Support Type</th>
            <th>Description</th>
            <th>Amount (Ksh)</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['support_date']; ?></td>
            <td><?php echo ucfirst($row['support_type']); ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo number_format($row['amount'], 2); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
    <p><a href="member.php">⬅ Back to Dashboard</a></p>
</div>
</body>
</html>
