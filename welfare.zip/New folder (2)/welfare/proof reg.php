<?php
include "config.php";

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_FILES['payment_proof'])) {
    $username = $conn->real_escape_string($_POST['username']);

    // find user
    $res = $conn->query("SELECT id FROM users WHERE username='$username'");
    if ($res->num_rows == 0) {
        die("User not found.");
    }
    $user = $res->fetch_assoc();
    $user_id = $user['id'];

    // handle file
    $targetDir = "uploads/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

    $fileName = time() . "_" . basename($_FILES["payment_proof"]["name"]);
    $targetFile = $targetDir . $fileName;

    if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $targetFile)) {
        // save path in DB
        $conn->query("UPDATE payment_proofs SET proof_file='$fileName' WHERE user_id='$user_id'");
        echo "Proof uploaded successfully! Awaiting admin verification.";
    } else {
        echo "Error uploading file.";
    }
}
?>
