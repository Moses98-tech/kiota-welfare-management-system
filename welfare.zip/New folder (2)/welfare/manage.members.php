<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'chairman') {
    header("Location: signin.php");
    exit;
}

require_once "config.php";

// Handle status update
if (isset($_POST['update_status'])) {
    $id = intval($_POST['user_id']);
    $new_status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage.members.php");
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage.members.php");
    exit;
}

// Fetch members
$result = $conn->query("SELECT id, username, email, created_at, status FROM users ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Members - Kiota Welfare</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: linear-gradient(to right, #2c5364, #203a43, #0f2027);
            color: #f4f4f9;
            margin: 0;
            padding: 30px;
        }
        .container {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(8px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
            max-width: 1000px;
            margin: auto;
        }
        h1 {
            text-align: center;
            color: #ffca28;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }
        table thead {
            background: rgba(255,255,255,0.2);
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.2);
        }
        table tr:hover {
            background: rgba(255,255,255,0.05);
        }
        a.btn, button.btn {
            padding: 6px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
            border: none;
            cursor: pointer;
        }
        .edit { background: #42a5f5; color: white; }
        .edit:hover { background: #1565c0; }
        .delete { background: #ef5350; color: white; }
        .delete:hover { background: #c62828; }
        .back {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            border-radius: 20px;
            background: #26a69a;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        .back:hover { background: #00796b; }
        select {
            padding: 5px;
            border-radius: 6px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Manage Members</h1>
    <table>
        <thead>
        <tr>
            <th>#</th>
            <th>Username</th>
            <th>Email</th>
            <th>Joined</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']); ?></td>
                    <td><?= htmlspecialchars($row['username']); ?></td>
                    <td><?= htmlspecialchars($row['email']); ?></td>
                    <td><?= htmlspecialchars($row['created_at']); ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="user_id" value="<?= $row['id']; ?>">
                            <select name="status">
                                <option value="inactive" <?= $row['status']=='inactive'?'selected':''; ?>>Inactive</option>
                                <option value="active" <?= $row['status']=='active'?'selected':''; ?>>Active</option>
                            </select>
                            <button type="submit" name="update_status" class="btn edit">Update</button>
                        </form>
                    </td>
                    <td>
                        <a class="btn delete" href="manage.members.php?delete=<?= $row['id']; ?>" onclick="return confirm('Delete this member?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">No members found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <a href="chairman.php" class="back">⬅ Back to Dashboard</a>
</div>
</body>
</html>
