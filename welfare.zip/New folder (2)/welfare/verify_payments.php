<?php
session_start();
include "config.php";

// Only treasurer or admin allowed
if ($_SESSION['role'] !== 'treasurer' && $_SESSION['role'] !== 'admin') {
    die("Access Denied!");
}

// Handle approval/rejection
if (isset($_GET['approve_id'])) {
    $id = intval($_GET['approve_id']);
    $conn->query("UPDATE payment_proofs SET status='Approved' WHERE id=$id");
    header("Location: verify_payments.php?status=Pending&success=1");
    exit;
}
elseif (isset($_GET['reject_id'])) {
    $id = intval($_GET['reject_id']);
    $conn->query("UPDATE payment_proofs SET status='Rejected' WHERE id=$id");
    header("Location: verify_payments.php?status=Pending&rejected=1");
    exit;
}

// Status filter
$statusFilter = $_GET['status'] ?? 'Pending';

// Fetch payments based on filter (✅ now selecting mpesa_code)
$stmt = $conn->prepare("
    SELECT id, username, amount, mpesa_code, proof_file, uploaded_at, status
    FROM payment_proofs
    WHERE status=?
    ORDER BY uploaded_at DESC
");
$stmt->bind_param("s", $statusFilter);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Treasurer - Verify Payments</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f9f9f9; padding: 20px; }
    h2 { color: #1B5E20; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
    th { background: #1B5E20; color: white; }
    a.btn {
      padding: 6px 12px; border-radius: 5px; text-decoration: none; font-weight: bold;
    }
    .approve { background: #43A047; color: white; }
    .approve:hover { background: #2e7d32; }
    .reject { background: #e53935; color: white; }
    .reject:hover { background: #b71c1c; }
    .filters a { margin: 0 8px; text-decoration: none; font-weight: bold; }
    .active-filter { color: #1B5E20; text-decoration: underline; }
  </style>
</head>
<body>

<h2>Payment Proof Verification</h2>

<!-- Filter Links -->
<p class="filters">
  <a href="verify_payments.php?status=Pending" class="<?= $statusFilter=='Pending' ? 'active-filter':'' ?>">Pending</a> |
  <a href="verify_payments.php?status=Approved" class="<?= $statusFilter=='Approved' ? 'active-filter':'' ?>">Approved</a> |
  <a href="verify_payments.php?status=Rejected" class="<?= $statusFilter=='Rejected' ? 'active-filter':'' ?>">Rejected</a>
</p>

<?php if (isset($_GET['success'])): ?>
  <p style="color:green;">Payment approved successfully!</p>
<?php endif; ?>
<?php if (isset($_GET['rejected'])): ?>
  <p style="color:red;">Payment rejected successfully!</p>
<?php endif; ?>

<table>
  <tr>
    <th>Member</th>
    <th>Amount</th>
    <th>M-Pesa Code</th> <!-- ✅ New Column -->
    <th>Proof</th>
    <th>Date Uploaded</th>
    <th>Status</th>
    <th>Action</th>
  </tr>
  <?php if ($result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($row['username']) ?></td>
      <td><?= number_format($row['amount'],2) ?></td>
      <td><?= htmlspecialchars($row['mpesa_code']) ?></td> <!-- ✅ Show Mpesa -->
      <td>
        <?php if ($row['proof_file']): ?>
          <a href="uploads/<?= htmlspecialchars($row['proof_file']) ?>" target="_blank">View Proof</a>
        <?php else: ?>
          No File
        <?php endif; ?>
      </td>
      <td><?= $row['uploaded_at'] ?></td>
      <td><?= ucfirst($row['status']) ?></td>
      <td>
        <?php if ($row['status'] == 'Pending'): ?>
          <a class="btn approve" href="?approve_id=<?= $row['id'] ?>&status=<?= $statusFilter ?>">Approve</a>
          <a class="btn reject" href="?reject_id=<?= $row['id'] ?>&status=<?= $statusFilter ?>">Reject</a>
        <?php else: ?>
          -
        <?php endif; ?>
      </td>
    </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr><td colspan="7">No payment proofs found for this status.</td></tr>
  <?php endif; ?>
</table>

<p><a href="treasurer.php">⬅ Back </a></p>
</body>
</html>
