<?php
session_start();
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'treasurer') {
    header("Location: signin.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $support_type = $_POST['support_type'];
    $amount = $_POST['amount'];
    $description = $_POST['description'];
    $support_date = date("Y-m-d");

    $stmt = $conn->prepare("INSERT INTO welfare_support (user_id, support_type, amount, support_date, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isdss", $user_id, $support_type, $amount, $support_date, $description);

    if ($stmt->execute()) {
        $message = "Support recorded successfully!";
    } else {
        $message = " Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch members for dropdown
$members = $conn->query("SELECT id, username FROM users WHERE role='member'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Record Support - Kiota Welfare</title>
    <style>
        body { font-family: Arial; background:url('images/treasurer-bg.jpg') no-repeat center center fixed; background-size:cover; color:#fff; }
        .container { background:rgba(0,0,0,0.8); padding:30px; width:50%; margin:50px auto; border-radius:10px; box-shadow:0 0 10px #000; }
        h1 { color:#ff9800; }
        form { display:flex; flex-direction:column; gap:15px; }
        label { font-weight:bold; text-align:left; }
        input, select, textarea { padding:10px; border:none; border-radius:5px; }
        button { background:#2196F3; color:#fff; padding:10px; border:none; border-radius:5px; cursor:pointer; }
        button:hover { background:#1976D2; }
        .msg { margin:10px 0; font-weight:bold; }
        a { color:#ff9800; text-decoration:none; display:inline-block; margin-top:15px; }
        a:hover { text-decoration:underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>Record Welfare Support</h1>

    <?php if ($message): ?>
        <p class="msg"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="user_id">Select Member:</label>
        <select name="user_id" required>
            <option value="">-- Choose Member --</option>
            <?php while ($row = $members->fetch_assoc()): ?>
                <option value="<?php echo $row['id']; ?>"><?php echo $row['username']; ?></option>
            <?php endwhile; ?>
        </select>

        <label for="support_type">Support Type:</label>
        <select name="support_type" required>
            <option value="sickness">Sickness</option>
            <option value="bereavement">Bereavement</option>
        </select>

        <label for="amount">Amount (Ksh):</label>
        <input type="number" step="0.01" name="amount" required>

        <label for="description">Description:</label>
        <textarea name="description" rows="3" placeholder="E.g. Hospital support or Funeral contribution"></textarea>

        <button type="submit">Save Support</button>
    </form>

    <a href="treasurer.php">⬅ Back to Dashboard</a>
</div>
</body>
</html>
