<?php
session_start();
include "config.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $res = $conn->query("SELECT * FROM users WHERE username='$username' LIMIT 1");
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role']    = $row['role'];

            // role-based redirect response
            if ($row['role'] == "treasurer") {
                echo "treasurer";
            } elseif ($row['role'] == "chairman") {
                echo "chairman";
            } else {
                echo "member";
            }
        } else {
            echo "wrong";
        }
    } else {
        echo "notfound";
    }
}
?>
