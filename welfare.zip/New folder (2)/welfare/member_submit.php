<?php
require_once "config.php";
session_start();
if (!isset($_SESSION['user_id'])) {
    die("You must login first.");
}

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $support_type = $_POST['support_type'];
    $description = $_POST['description'];
    $amount_requested = $_POST['amount_requested'];

    // Handle file upload
    $targetDir = "uploads/";
    $fileName = time() . "_" . basename($_FILES["proof_file"]["name"]);
    $targetFile = $targetDir . $fileName;

    if (move_uploaded_file($_FILES["proof_file"]["tmp_name"], $targetFile)) {
        $stmt = $conn->prepare("INSERT INTO welfare_claims (user_id, support_type, description, proof_file, amount_requested) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isssd", $user_id, $support_type, $description, $fileName, $amount_requested);
        if ($stmt->execute()) {
            $message = "Claim submitted successfully ✅";
        } else {
            $message = "Error: " . $stmt->error;
        }
    } else {
        $message = "File upload failed.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Submit Welfare Claim</title>
    <style>
        body { font-family: Arial; background:#f4f6f9; padding:30px; }
        form { background:white; padding:20px; border-radius:10px; width:400px; margin:auto; }
        input, select, textarea { width:100%; padding:10px; margin:8px 0; border:1px solid #ccc; border-radius:5px; }
        button { background:#2e7d32; color:white; padding:10px; border:none; border-radius:5px; cursor:pointer; }
        button:hover { background:#1b5e20; }
        .msg { margin:10px 0; color:green; font-weight:bold; }
    </style>
</head>
<body>
    <h2>Submit Welfare Claim</h2>
    <?php if ($message) echo "<p class='msg'>$message</p>"; ?>
    <form method="post" enctype="multipart/form-data">
        <label>Support Type:</label>
        <select name="support_type" required>
            <option value="bereavement">Bereavement</option>
            <option value="sickness">Sickness</option>
        </select>

        <label>Description:</label>
        <textarea name="description" required></textarea>

        <label>Amount Requested (KES):</label>
        <input type="number" step="0.01" name="amount_requested" required>

        <label>Upload Proof (PDF/Image):</label>
        <input type="file" name="proof_file" required>

        <button type="submit">Submit Claim</button>
    </form>
    <p><a href="member.php">⬅ Back to Dashboard</a></p>
</body>
</html>
