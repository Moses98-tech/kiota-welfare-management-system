<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'chairman') {
    header("Location: signin.php"); 
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chairman Dashboard - Kiota Welfare</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: linear-gradient(to right, #1e3c72, #2a5298);
            color: #f4f4f9;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px;
        }

        .dashboard {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            width: 100%;
            max-width: 900px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        .dashboard h1 {
            font-size: 2.5rem;
            color: #ffca28;
            margin-bottom: 10px;
        }

        .dashboard p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            color: #e0e0e0;
        }

        .links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .links a {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            padding: 15px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(135deg, #42a5f5, #1565c0);
            box-shadow: 0 5px 12px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }

        .links a:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 12px 20px rgba(0,0,0,0.4);
        }

        .logout {
            display: inline-block;
            padding: 12px 25px;
            border-radius: 25px;
            background: #ef5350;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .logout:hover {
            background: #c62828;
        }

        footer {
            margin-top: 25px;
            font-size: 0.9rem;
            color: #bbb;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <h1>Welcome Chairman </h1>
        <p>You have full access to manage Kiota Welfare.</p>
        
        <div class="links">
            <a href="manage.members.php"> Manage Members</a>
            <a href="view_contributions_all.php">All Contributions</a>
            <a href="contribution report.php">Contributions Report</a>
            
            <a href="view.support.all.php"> Welfare Support</a>
            <a href="generate.reports.php">Generate Reports</a>
            <a href="report_welfare.php">Welfare Report</a>
            <a href="report.reg.php">Registration Fees Report</a>
            <a href="announcements.php"> Post Announcements</a>
            <a href="sendmail.php"> Send Email</a>

        </div>

        <a href="main1.php" class="logout"> Logout</a>
        
    </div>
</body>
</html>
