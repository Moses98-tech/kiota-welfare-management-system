<?php
// file: report_welfare.php
require_once "config.php"; // DB connection

// Fetch all contributions from welfare_support table
$sql = "SELECT w.id, u.username, w.support_type, w.amount, w.support_date, w.description, w.remarks, w.created_at
        FROM welfare_support w
        JOIN users u ON w.user_id = u.id
        ORDER BY w.support_date DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welfare Contributions Report</title>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #2e7d32;
      margin-bottom: 20px;
    }
    .table-container {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    table.dataTable {
      width: 100% !important;
      border-radius: 10px;
      overflow: hidden;
    }
    tfoot {
      font-weight: bold;
      background: #e8f5e9;
    }
  </style>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
</head>
<body>

  <h2>Welfare Contributions Report</h2>

  <div class="table-container">
    <table id="reportTable" class="display nowrap">
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Support Type</th>
          <th>Amount</th>
          <th>Support Date</th>
          <th>Description</th>
          <th>Remarks</th>
          <th>Created At</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $grand_total = 0;
        if ($result && $result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
            $grand_total += $row['amount'];
            echo "<tr>
              <td>{$row['id']}</td>
              <td>{$row['username']}</td>
              <td>{$row['support_type']}</td>
              <td>{$row['amount']}</td>
              <td>{$row['support_date']}</td>
              <td>{$row['description']}</td>
              <td>{$row['remarks']}</td>
              <td>{$row['created_at']}</td>
            </tr>";
          }
        }
        ?>
      </tbody>
      <tfoot>
        <tr>
          <th colspan="3" style="text-align:right">Total Contributions:</th>
          <th><?php echo "KES " . number_format($grand_total, 2); ?></th>
          <th colspan="4"></th>
        </tr>
      </tfoot>
    </table>
  </div>
  <p><a href="chairman.php">⬅ Back to Dashboard</a></p>

<script>
$(document).ready(function() {
  $('#reportTable').DataTable({
    dom: 'Bfrtip',
    buttons: ['excelHtml5', 'pdfHtml5', 'print']
  });
});
</script>

</body>
</html>
