<?php
require_once "config.php"; // DB connection

// Handle delete
if (isset($_GET['delete_user'])) {
    $delete_user = intval($_GET['delete_user']);
    $conn->query("DELETE FROM contributions WHERE user_id = $delete_user");
    header("Location: report.php"); // refresh page after delete
    exit();
}

$filter = $_GET['filter'] ?? 'month';
$year   = $_GET['year'] ?? date("Y");
$month  = $_GET['month'] ?? date("m");
$half   = $_GET['half'] ?? 1;

// Semi-annual ranges
$start = ($half == 1) ? "$year-01-01" : "$year-07-01";
$end   = ($half == 1) ? "$year-06-30" : "$year-12-31";

// Build query
if ($filter === 'month') {
    $stmt = $conn->prepare("SELECT u.id, u.username, SUM(c.amount) AS total
                            FROM contributions c
                            JOIN users u ON c.user_id = u.id
                            WHERE YEAR(c.contribution_date) = ? 
                              AND MONTH(c.contribution_date) = ?
                            GROUP BY u.id, u.username");
    $stmt->bind_param("ii", $year, $month);

} elseif ($filter === 'year') {
    $stmt = $conn->prepare("SELECT u.id, u.username, SUM(c.amount) AS total
                            FROM contributions c
                            JOIN users u ON c.user_id = u.id
                            WHERE YEAR(c.contribution_date) = ?
                            GROUP BY u.id, u.username");
    $stmt->bind_param("i", $year);

} else { // semi-annual
    $stmt = $conn->prepare("SELECT u.id, u.username, SUM(c.amount) AS total
                            FROM contributions c
                            JOIN users u ON c.user_id = u.id
                            WHERE c.contribution_date BETWEEN ? AND ?
                            GROUP BY u.id, u.username");
    $stmt->bind_param("ss", $start, $end);
}

$stmt->execute();
$result = $stmt->get_result();

// Total Collection
$totalStmt = $conn->query("SELECT SUM(amount) AS grand_total FROM contributions");
$grandTotal = $totalStmt->fetch_assoc()['grand_total'] ?? 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Memnber Contribution Report</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f1f8e9; }
        table { width: 80%; border-collapse: collapse; margin: 20px auto; box-shadow: 0px 2px 8px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background: #388e3c; color: white; }
        tr:nth-child(even) { background: #f9fbe7; }
        h2 { text-align: center; color: #1b5e20; }
        a.delete-btn {
            background: #e53935; color: white; padding: 5px 10px;
            text-decoration: none; border-radius: 5px;
        }
        a.delete-btn:hover { background: #b71c1c; }
    </style>
</head>
<body>
    <h2>Member Contribution Report (<?= ucfirst($filter) ?>)</h2>

    <table>
        <tr>
            <th>Member</th>
            <th>Total Contribution</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= number_format($row['total'], 2) ?></td>
                <td>
                    <a class="delete-btn" 
                       href="?delete_user=<?= $row['id'] ?>" 
                       onclick="return confirm('Delete all contributions for <?= htmlspecialchars($row['username']) ?>?')">
                       Delete
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
        <tr style="font-weight:bold; background:#c8e6c9">
            <td>Total Collected this Month:</td>
            <td colspan="2"><?= number_format($grandTotal, 2) ?></td>
        </tr>
    </table>
    <p><a href="chairman.php">⬅ Back </a></p>
</body>
</html>
