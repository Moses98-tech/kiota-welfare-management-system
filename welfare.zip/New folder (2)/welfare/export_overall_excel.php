<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

// Fetch contributions per member
$contrib_sql = "
    SELECT u.username, SUM(c.amount) AS total_contrib 
    FROM users u 
    LEFT JOIN contributions c ON u.id = c.user_id 
    GROUP BY u.id
";
$contrib_result = $conn->query($contrib_sql);

// Fetch support per member
$support_sql = "
    SELECT u.username, SUM(s.amount) AS total_support 
    FROM users u 
    LEFT JOIN support s ON u.id = s.user_id 
    GROUP BY u.id
";
$support_result = $conn->query($support_sql);

// Merge data
$report = [];
while($row = $contrib_result->fetch_assoc()){
    $report[$row['username']]['contrib'] = $row['total_contrib'] ?? 0;
}
while($row = $support_result->fetch_assoc()){
    $report[$row['username']]['support'] = $row['total_support'] ?? 0;
}

// Output headers to force download as Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=overall_reports.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Output the data
echo "Member\tTotal Contributions (Ksh)\tTotal Support (Ksh)\tNet Balance (Ksh)\n";

foreach($report as $username => $data){
    $total_contrib = $data['contrib'] ?? 0;
    $total_support = $data['support'] ?? 0;
    $net = $total_contrib - $total_support;

    echo "$username\t$total_contrib\t$total_support\t$net\n";
}
?>
