<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'chairman') {
    header("Location: signin.php");
    exit;
}

include 'config.php';

// Handle announcement submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['title'], $_POST['message'], $_POST['recipient'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $message = $conn->real_escape_string($_POST['message']);
    $recipient = $_POST['recipient'];

    $stmt = $conn->prepare("INSERT INTO announcements (title, message, recipient_role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $message, $recipient);
    $stmt->execute();
    $stmt->close();
    $success = "Announcement sent successfully!";
}

// Handle deletion via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM announcements WHERE id = ?");
    if (!$stmt) { die("Prepare failed: " . $conn->error); }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: announcements.php");
    exit;
}

// Fetch announcements
$announcements = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chairman Announcements - Kiota Welfare</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
                        url('images/chairman-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
            min-height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 0;
        }

        .container {
            background: rgba(0,0,0,0.65);
            backdrop-filter: blur(8px);
            border-radius: 20px;
            padding: 30px;
            width: 90%;
            max-width: 900px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }

        h1, h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #ffca28;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 30px;
        }

        input, textarea, select, button {
            padding: 12px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
        }

        input, textarea, select {
            width: 100%;
        }

        button.submit-btn {
            background: #42a5f5;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        button.submit-btn:hover {
            background: #1565c0;
        }

        .announcement {
            background: rgba(255,255,255,0.05);
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 15px;
            position: relative;
        }

        .announcement strong {
            font-size: 1.1rem;
            color: #ffeb3b;
        }

        .announcement small {
            color: #ccc;
        }

        .delete-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            background: #ef5350;
            color: #fff;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            cursor: pointer;
            transition: 0.3s;
        }

        .delete-btn:hover {
            background: #c62828;
        }

        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            text-align: center;
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 25px;
            border-radius: 25px;
            background: #26a69a;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .back-btn:hover {
            background: #00796b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1> Manage Announcements</h1>

        <?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>

        <form method="post">
            <input type="text" name="title" placeholder="Title" required>
            <textarea name="message" placeholder="Message" rows="4" required></textarea>
            <select name="recipient" required>
                <option value="all">All Members</option>
                <option value="member">Members Only</option>
                <option value="treasurer">Treasurer Only</option>
            </select>
            <button type="submit" class="submit-btn">Send Announcement</button>
        </form>

        <h2>Previous Announcements</h2>
        <?php if($announcements->num_rows > 0): ?>
            <?php while($row = $announcements->fetch_assoc()): ?>
                <div class="announcement">
                    <strong><?= htmlspecialchars($row['title']); ?></strong> 
                    <em>(To: <?= htmlspecialchars($row['recipient_role']); ?>)</em><br>
                    <?= nl2br(htmlspecialchars($row['message'])); ?><br>
                    <small>Sent on <?= $row['created_at']; ?></small>

                    <form method="post" style="display:inline;">
                        <input type="hidden" name="delete_id" value="<?= $row['id']; ?>">
                        <button type="submit" class="delete-btn" onclick="return confirm('Delete this announcement?');">Delete</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No announcements yet.</p>
        <?php endif; ?>

        <a href="chairman.php" class="back-btn">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
