<?php
session_start();
if ($_SESSION['role'] != 'chairman') { 
    header("Location: index.html"); 
    exit; 
}
include 'config.php';

if (!isset($_GET['id'])) {
    die(" Support ID is missing.");
}

$id = intval($_GET['id']);

// Fetch the support record
$sql = "SELECT * FROM welfare_support WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die(" Support record not found.");
}

$support = $result->fetch_assoc();

$success_message = "";

// Handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $support_type = $_POST['support_type'];
    $amount = $_POST['amount'];
    $support_date = $_POST['support_date'];
    $description = $_POST['description'];

    $update = "UPDATE welfare_support SET support_type=?, amount=?, support_date=?, description=? WHERE id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("sdssi", $support_type, $amount, $support_date, $description, $id);

    if ($stmt->execute()) {
        $success_message = "✅ Record updated successfully!";
        // refresh record so form shows updated values
        $sql = "SELECT * FROM welfare_support WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $support = $stmt->get_result()->fetch_assoc();
    } else {
        $success_message = "❌ Error updating record.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Support Record</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px; }
        .container { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; }
        form { display: flex; flex-direction: column; }
        label { margin-top: 10px; }
        input, textarea, select { padding: 10px; margin-top: 5px; border: 1px solid #ccc; border-radius: 6px; }
        button { margin-top: 15px; padding: 12px; background: #007bff; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .message { text-align: center; margin-bottom: 15px; font-weight: bold; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h2> Edit Support Record</h2>

        <?php if ($success_message): ?>
            <p class="message <?= strpos($success_message, '✅') !== false ? 'success' : 'error' ?>">
                <?= $success_message ?>
            </p>
        <?php endif; ?>

        <form method="post">
            <label>Support Type:</label>
            <input type="text" name="support_type" value="<?= htmlspecialchars($support['support_type']) ?>" required>

            <label>Amount (Ksh):</label>
            <input type="number" step="0.01" name="amount" value="<?= htmlspecialchars($support['amount']) ?>" required>

            <label>Date:</label>
            <input type="date" name="support_date" value="<?= htmlspecialchars($support['support_date']) ?>" required>

            <label>Description:</label>
            <textarea name="description"><?= htmlspecialchars($support['description']) ?></textarea>

            <button type="submit"> Update Record</button>
        </form>
         <p><a href="view.support.all.php">⬅ Back </a></p>
    </div>
</body>
</html>
