<?php
require_once "config.php";
session_start();

// Update claim status
if (isset($_GET['id'], $_GET['action'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];
    if (in_array($action, ['approved','rejected'])) {
        $stmt = $conn->prepare("UPDATE welfare_claims SET status=? WHERE id=?");
        $stmt->bind_param("si", $action, $id);
        $stmt->execute();
    }
}

$sql = "SELECT c.id, u.username, c.support_type, c.amount_requested, c.description, c.proof_file, c.status, c.submitted_at
        FROM welfare_claims c
        JOIN users u ON c.user_id=u.id
        ORDER BY c.submitted_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Welfare Claims</title>
    <style>
        body { font-family: Arial; background:#f4f6f9; padding:30px; }
        table { width:100%; border-collapse:collapse; background:white; }
        th,td { border:1px solid #ddd; padding:10px; text-align:center; }
        th { background:#2e7d32; color:white; }
        .btn { padding:5px 10px; border-radius:5px; text-decoration:none; color:white; }
        .approve { background:#2e7d32; }
        .reject { background:#c62828; }
        .pending { color:#ff9800; font-weight:bold; }
        .approved { color:#2e7d32; font-weight:bold; }
        .rejected { color:#c62828; font-weight:bold; }
    </style>
</head>
<body>
<h2>Manage Welfare Claims</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Member</th>
        <th>Type</th>
        <th>Amount Requested</th>
        <th>Description</th>
        <th>Proof</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        while ($row=$result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['username']}</td>
                <td>{$row['support_type']}</td>
                <td>{$row['amount_requested']}</td>
                <td>{$row['description']}</td>
                <td><a href='uploads/{$row['proof_file']}' target='_blank'>View Proof</a></td>
                <td class='{$row['status']}'>{$row['status']}</td>
                <td>";
                if ($row['status']=='pending') {
                    echo "<a class='btn approve' href='?id={$row['id']}&action=approved'>Approve</a> 
                          <a class='btn reject' href='?id={$row['id']}&action=rejected'>Reject</a>";
                } else {
                    echo "—";
                }
            echo "</td></tr>";
        }
    } else {
        echo "<tr><td colspan='8'>No claims submitted yet.</td></tr>";
    }
    ?>
</table>
<p><a href="treasurer.php">⬅ Back to Dashboard</a></p>
</body>
</html>
