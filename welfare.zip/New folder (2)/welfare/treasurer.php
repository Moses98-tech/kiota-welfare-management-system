<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'treasurer') {
    header("Location: signin.php");
    exit;
}
include 'config.php';

// Fetch announcements relevant to treasurers
$announcements = $conn->query("SELECT * FROM announcements WHERE recipient_role IN ('all','treasurer') ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Treasurer Dashboard - Kiota Welfare</title>
<style>
    body {
        margin: 0;
        font-family: "Segoe UI", Tahoma, sans-serif;
        background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
                    url('images/treasurer-bg.jpg') no-repeat center center fixed;
        background-size: cover;
        color: #f4f4f9;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding-top: 50px;
        min-height: 100vh;
    }

    .dashboard {
        background: rgba(255,255,255,0.1);
        backdrop-filter: blur(8px);
        padding: 40px;
        border-radius: 20px;
        width: 90%;
        max-width: 800px;
        text-align: center;
        box-shadow: 0 10px 25px rgba(0,0,0,0.4);
        animation: fadeIn 1s ease-in-out;
    }

    h1 { font-size: 2rem; margin-bottom: 10px; color: #4CAF50; }
    p { margin-bottom: 25px; font-size: 1.1rem; }

    .links {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .links a {
        display: block;
        padding: 15px;
        border-radius: 12px;
        text-decoration: none;
        font-weight: bold;
        color: #fff;
        background: linear-gradient(135deg, #4CAF50, #2e7d32);
        box-shadow: 0 5px 12px rgba(0,0,0,0.3);
        transition: all 0.3s ease-in-out;
    }

    .links a:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.5);
    }

    .logout {
        display: inline-block;
        margin-top: 15px;
        padding: 12px 25px;
        border-radius: 25px;
        background: #ef5350;
        color: #fff;
        text-decoration: none;
        font-weight: bold;
        transition: 0.3s ease;
    }

    .logout:hover { background: #c62828; }

    /* Announcements */
    .announcement-section { text-align:left; margin-top:30px; }
    .announcement { background: rgba(255,255,255,0.1); padding:15px; border-radius:10px; margin-bottom:15px; }
    .announcement strong { color:#00e676; }
    .announcement small { display:block; margin-top:5px; font-size:0.8rem; color:#ccc; }

    @keyframes fadeIn {
        from { opacity:0; transform:translateY(-20px); }
        to { opacity:1; transform:translateY(0); }
    }
</style>
</head>
<body>
<div class="dashboard">
    <h1>Welcome Treasurer </h1>
    <p>You are responsible for managing finances and welfare support records.</p>

    <div class="links">
        <a href="view_proofs.php"> View Proofs of Contributions</a>
        <a href="record_contributions.php"> Record Contributions</a>
        <a href="manage_claims.php"> Claims of Welfare Support</a>
        <a href="record.php"> Record Welfare Support</a>
        <a href="view_reports.php"> View Financial Reports</a>
         <a href="verify_payments.php"> View Registration Fees</a>
    </div>

    <h3> Announcements</h3>
    <div class="announcement-section">
        <?php if($announcements->num_rows > 0): ?>
            <?php while($row = $announcements->fetch_assoc()): ?>
                <div class="announcement">
                    <strong><?= htmlspecialchars($row['title']); ?></strong><br>
                    <?= nl2br(htmlspecialchars($row['message'])); ?>
                    <small>Sent on <?= $row['created_at']; ?></small>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No announcements yet.</p>
        <?php endif; ?>
    </div>

    <a href="main1.php" class="logout">Logout</a>
</div>
</body>
</html>
